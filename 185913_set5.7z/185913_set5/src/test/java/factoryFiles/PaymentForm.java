package factoryFiles;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentForm {
	
	WebDriver driver;
	
	@FindBy(how = How.ID, using = "txtCardholderName")
	@CacheLookup
	WebElement CardHolderName;
	
	@FindBy(how = How.ID, using = "txtDebit")
	@CacheLookup
	WebElement CardNumber;
	
	@FindBy(how = How.ID, using = "txtCvv")
	@CacheLookup
	WebElement CVV;
	
	@FindBy(how = How.ID, using = "txtMonth")
	@CacheLookup
	WebElement ExpMonth;
	
	@FindBy(how = How.ID, using = "txtYear")
	@CacheLookup
	WebElement ExpYear;
	
	
	@FindBy(how=How.ID, using="btnPayment")
	@CacheLookup
	WebElement confirmButton;


	public WebDriver getDriver() {
		return driver;
	}


	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public WebElement getCardHolderName() {
		return CardHolderName;
	}


	public void setCardHolderName(String CardHolderName) {
		this.CardHolderName.sendKeys(CardHolderName);
	}


	public WebElement getCardNumber() {
		return CardNumber;
	}


	public void setCardNumber(String CardNumber) {
		this.CardNumber.sendKeys(CardNumber);
	}


	public WebElement getCVV() {
		return CVV;
	}


	public void setCVV(String CVV) {
		this.CVV.sendKeys(CVV);
	}


	public WebElement getExpMonth() {
		return ExpMonth;
	}


	public void setExpMonth(String ExpMonth) {
		this.ExpMonth.sendKeys(ExpMonth);
	}


	public WebElement getExpYear() {
		return ExpYear;
	}


	public void setExpYear(String ExpYear) {
		this.ExpYear.sendKeys(ExpYear);
	}


	public WebElement getConfirmButton() {
		return confirmButton;
	}


	public void setConfirmButton(String string) {
		this.confirmButton.click();
	}
	public PaymentForm(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	

}
