package factoryFiles;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RegistrationForm {

	WebDriver driver;

	@FindBy(name = "txtNM")
	@CacheLookup
	WebElement ApplicantName;

	
	
	@FindBy(how = How.ID, using = "txtFirstName")
	@CacheLookup
	WebElement FirstName;

	@FindBy(how = How.ID, using = "txtLastName")
	@CacheLookup
	WebElement LastName;

	@FindBy(how=How.ID,using = "txtFatherName")
	@CacheLookup
	WebElement FatherName;

	@FindBy(name = "txtDOB")
	@CacheLookup
	WebElement DOB;
	
	@FindBy(how=How.ID, using="btnSubmit")
	@CacheLookup
	WebElement confirmButton;

	@FindBy(how = How.NAME, using = "* Gender :")
	@CacheLookup
	WebElement Gender;

	@FindBy(name = "txtMNo")
	@CacheLookup
	WebElement MobileNumber;

	@FindBy(how = How.NAME, using = "* Email ID :")
	@CacheLookup
	WebElement Mail;

	@FindBy(name = "txtLLine")
	@CacheLookup
	WebElement LandLine;

	@FindBy(how = How.NAME, using = "* Communicaton :")
	@CacheLookup
	WebElement Communication;
	
	@FindBy(how = How.NAME, using = "* Communicaton :")
	@CacheLookup
	WebElement Address;

	public WebElement getAddress() {
		return Address;
	}

	public void setAddress(String Address) {
		this.Address.sendKeys(Address);
	
	}

	public Object setGender;

	public WebElement getApplicantName() {
		return ApplicantName;
	}

	public void setApplicantName(String ApplicantName) {
		this.ApplicantName.sendKeys(ApplicantName);
	}

	public WebElement getFirstName() {
		return FirstName;
	}

	public void setFirtName(String FirstName) {
		this.FirstName.sendKeys(FirstName);
	}

	public WebElement getLastName() {
		return LastName;
	}

	public void setLastName(String LastName) {
		this.LastName.sendKeys(LastName);
	}

	public WebElement getFatherName() {
		return FatherName;
	}

	public void setFatherName(String FatherName) {
		this.FatherName.sendKeys(FatherName);
	}
	
	public WebElement getConfirmButton() {
		return confirmButton;
	}

	public void setConfirmButton(String confirmButton) {
		this.confirmButton.click();
	}

	public WebElement getDOB() {
		return DOB;
	}

	public void setDOB(String DOB) {
		this.DOB.sendKeys(DOB);
	}

	public WebElement getGender() {
		return Gender;
	}

	public void setGender(String Gender) {
		this.Gender.click();
	}

	public WebElement getMobileNumber() {
		return MobileNumber;
	}

	public void setMobileNumber(String MobileNumber) {
		this.MobileNumber.sendKeys(MobileNumber);
	}

	public WebElement getMail() {
		return Mail;
	}

	public void setMail(String Mail) {
		this.Mail.sendKeys(Mail);
	}

	public WebElement getLandLine() {
		return LandLine;
	}

	public void setLandLine(String LandLine) {
		this.LandLine.sendKeys(LandLine);
	}

	public WebElement getCommunication() {
		return Communication;
	}

	public void setCommunication(String Communication) {
		this.Communication.sendKeys(Communication);
	}
	public RegistrationForm(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void choose(String string) {
		// TODO Auto-generated method stub
		
	}

}
