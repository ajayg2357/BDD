package userinformation;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import factoryFiles.RegistrationForm;

public class UserInformationStep {

	WebDriver driver;
	private RegistrationForm registrationForm;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\ajaybrowser\\chromedriver.exe");

		driver = new ChromeDriver();
	}

	@Given("^user is on 'userInfromation' page$")
	public void user_is_on_userInfromation_page() throws Throwable {
		driver.get("C:\\Users\\ajpadala\\Desktop\\ab\\185913_set5\\UserInformation.html");
		registrationForm = new RegistrationForm(driver);
	}

	@When("^user enters invalid applicant name$")
	public void user_enters_invalid_applicant_name() throws Throwable {
		registrationForm.setApplicantName("");
		registrationForm.setConfirmButton("");

	}

	@Then("^It displays 'Please! Enter the applicant name'$")
	public void it_displays_Please_Enter_the_applicant_name() throws Throwable {
		String expectedMessage = "Please fill the Applicant Name ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("");
		registrationForm.setConfirmButton("");
	}

	@Then("^It displays 'Please! Enter the first name'$")
	public void it_displays_Please_Enter_the_first_name() throws Throwable {
		String expectedMessage = "Please fill the First Name ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("Ajay");
		registrationForm.setLastName("");
		registrationForm.setConfirmButton("");
	}

	@Then("^It displays 'Please! Enter the last name'$")
	public void it_displays_Please_Enter_the_last_name() throws Throwable {
		String expectedMessage = "Please fill the Last Name ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid father name$")
	public void user_enters_invalid_father_name() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("Ajay");
		registrationForm.setLastName("Kalyan");
		registrationForm.setFatherName("");
		registrationForm.setConfirmButton("");
	}

	@Then("^It displays 'Please! Enter the father name'$")
	public void it_displays_Please_Enter_the_father_name() throws Throwable {
		String expectedMessage = "Please fill the Father Name ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid DOB$")
	public void user_enters_invalid_DOB() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("Ajay");
		registrationForm.setLastName("Kalyan");
		registrationForm.setFatherName("Govindu");
		registrationForm.setDOB("");
		registrationForm.setConfirmButton("");
	}

	@Then("^It displays 'Please! Enter the DOB'$")
	public void it_displays_Please_Enter_the_DOB() throws Throwable {
		String expectedMessage = "Please fill the DOB";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid gender$")
	public void user_enters_invalid_gender() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("Ajay");
		registrationForm.setLastName("Kalyan");
		registrationForm.setFatherName("Govindu");
		registrationForm.setDOB("22-12-1996");
		registrationForm.setGender("");
		registrationForm.setConfirmButton("");
	}

	@Then("^It displays 'Please! Enter the gender'$")
	public void it_displays_Please_Enter_the_gender() throws Throwable {
		String expectedMessage = "Please select the Gender";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();

	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("Ajay");
		registrationForm.setLastName("Kalyan");
		registrationForm.setFatherName("Govindu");
		registrationForm.setDOB("22-12-1996");
		registrationForm.setGender.click("");
		registrationForm.setMobileNumber("");
		registrationForm.setConfirmButton("");
	}

	@Then("^It displays 'Please! Enter the mobile number'$")
	public void it_displays_Please_Enter_the_mobile_number() throws Throwable {
		String expectedMessage = "Please fill Mobile no";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid mailId$")
	public void user_enters_invalid_mailId() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("Ajay");
		registrationForm.setLastName("Kalyan");
		registrationForm.setFatherName("Govindu");
		registrationForm.setDOB("22-12-1996");
		registrationForm.setGender("Male");
		registrationForm.setMobileNumber("9573726918");
		registrationForm.setMail("");
		registrationForm.setConfirmButton("");
	}

	@Then("^It displays 'Please! Enter the mailID'$")
	public void it_displays_Please_Enter_the_mailID() throws Throwable {
		String expectedMessage = "Please fill the Email id ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Customer enters incorrect mailId$")
	public void customer_enters_incorrect_mailId() throws Throwable {
		String expectedMessage = "Please enter valid Email id";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid land line number$")
	public void user_enters_invalid_land_line_number() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("Ajay");
		registrationForm.setLastName("Kalyan");
		registrationForm.setFatherName("Govindu");
		registrationForm.setDOB("22-12-1996");
		registrationForm.setGender("Male");
		registrationForm.setMobileNumber("9573726918");
		registrationForm.setMail("ajay-kalyan.padala@capgemini.com");
		registrationForm.setLandLine("");
		registrationForm.setConfirmButton("");

	}

	@Then("^It displays 'Please! Enter the land line number'$")
	public void it_displays_Please_Enter_the_land_line_number()
			throws Throwable {
		String expectedMessage = "please fill the landline no";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid communication name$")
	public void user_enters_invalid_communication_name() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("Ajay");
		registrationForm.setLastName("Kalyan");
		registrationForm.setFatherName("Govindu");
		registrationForm.setDOB("22-12-1996");
		registrationForm.setGender("Male");
		registrationForm.setMobileNumber("9573726918");
		registrationForm.setMail("ajay-kalyan.padala@capgemini.com");
		registrationForm.setLandLine("185913");
		registrationForm.setCommunication("");
		registrationForm.setConfirmButton("");
	}

	@Then("^It displays 'Please! Enter the communication name'$")
	public void it_displays_Please_Enter_the_communication_name()
			throws Throwable {
		String expectedMessage = "please enter the Addresss";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^user enters invalid Address$")
	public void user_enters_invalid_Address() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("Ajay");
		registrationForm.setLastName("Kalyan");
		registrationForm.setFatherName("Govindu");
		registrationForm.setDOB("22-12-1996");
		registrationForm.setGender("Male");
		registrationForm.setMobileNumber("9573726918");
		registrationForm.setMail("ajay-kalyan.padala@capgemini.com");
		registrationForm.setLandLine("185913");
		registrationForm.setCommunication("");
		registrationForm.setAddress("");
		registrationForm.setConfirmButton("");
	}

	@Then("^It displays 'Please! Enter the address'$")
	public void it_displays_Please_Enter_the_address()
			throws Throwable {
		String expectedMessage = "please enter the Addresss";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid details name$")
	public void user_enters_valid_details_name() throws Throwable {
		registrationForm.setApplicantName("Ajay Kalyan");
		registrationForm.setFirtName("Ajay");
		registrationForm.setLastName("Kalyan");
		registrationForm.setFatherName("Govindu");
		registrationForm.setDOB("22-12-1996");
		registrationForm.setGender("Male");
		registrationForm.setMobileNumber("9573726918");
		registrationForm.setMail("ajay-kalyan.padala@capgemini.com");
		registrationForm.setLandLine("185913");
		registrationForm.setCommunication("");
		registrationForm.setAddress("kadiam");
	}

	@Then("^It displays 'Congrats! Successfully Registered'$")
	public void it_displays_Congrats_Successfully_Registered() throws Throwable {
		driver.get("C:\\Users\\ajpadala\\Desktop\\ab\\185913_set5\\PaymentDetails.html");
		driver.close();
	}

}
